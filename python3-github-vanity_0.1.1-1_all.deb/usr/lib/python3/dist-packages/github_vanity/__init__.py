from .write import write_text

__all__ = [write_text]
